# include<stdio.h>
# include<stdlib.h>

int main()
{
	FILE *data, *new_data;
	char key[5], buffer[4100];
	fpos_t pos;

	data = fopen( "data.txt", "r" );
	if( !data )
		printf("error in data file\n");
	fgetpos( data, &pos );

	new_data = fopen( "new_data.txt", "w" );
	if( !new_data )
		printf("error in new_data file\n");

	fscanf( data, "%4s", key);
	while( fscanf( data, "%s", buffer) != EOF )
	{
		fprintf( new_data, "%4s", key);
		fscanf( data, "%4s", key);
	}
	fprintf( new_data, "\n" );
	
	fsetpos( data, &pos );
	
	fscanf( data, "%4s", key);
	while( fscanf( data, "%s", buffer) != EOF )
	{
		fprintf( new_data, "%s\n", buffer);
		fscanf( data, "%4s", key);
	}
	fprintf( new_data, "\n" );
	
	return 0;
}
